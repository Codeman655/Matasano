These serve no purpose other than to remind myself how it works, in case there's no 
"Useage" prompt. Anyway

Useage: ./b-xor-encrypt.rb <filename>
